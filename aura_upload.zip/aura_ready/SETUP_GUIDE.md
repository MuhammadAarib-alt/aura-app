# AURA – AI Life Manager
## Complete Setup Guide (Zero Cost)

---

## 📁 Project Structure
```
lib/
├── main.dart                    ← App entry point
├── theme/
│   └── app_theme.dart          ← Colors, fonts, theme
├── screens/
│   ├── splash_screen.dart      ← Animated splash (auto-navigates)
│   ├── onboarding_screen.dart  ← 5 intro slides (shows once)
│   ├── auth_screen.dart        ← Google Sign-In
│   ├── home_screen.dart        ← Main dashboard + all tabs
│   └── ai_chat_screen.dart     ← AURA AI chat (Gemini)
└── widgets/
    ├── energy_card.dart        ← Morning energy check-in
    ├── task_card.dart          ← Task list item
    └── stat_ring.dart          ← Circular progress stats
```

---

## 🚀 Step 1 — Install Flutter (Free)
1. Go to https://flutter.dev/docs/get-started/install
2. Download Flutter SDK for your OS (Windows/Mac/Linux)
3. Run `flutter doctor` — fix any issues it shows
4. Install Android Studio (free) for the Android emulator

---

## 🔑 Step 2 — Get Your Free API Keys

### Gemini API (AI Brain) — FREE
1. Go to https://aistudio.google.com
2. Click "Get API Key" → Create API key
3. Open `lib/screens/ai_chat_screen.dart`
4. Replace `'YOUR_GEMINI_API_KEY'` with your key
- Free tier: 15 requests/minute, 1M tokens/day — enough for hundreds of users

### Google Sign-In — FREE
1. Go to https://console.firebase.google.com
2. Create new project → "AURA"
3. Add Android app → package name: `com.yourname.aura`
4. Download `google-services.json` → place in `android/app/`
5. Enable Authentication → Sign-in method → Google → Enable
6. Add your SHA-1 key (run: `keytool -list -v -keystore ~/.android/debug.keystore`)

---

## 📦 Step 3 — Run the App
```bash
# Install dependencies
flutter pub get

# Run on connected device or emulator
flutter run

# Build APK for distribution
flutter build apk --release
# APK location: build/app/outputs/flutter-apk/app-release.apk
```

---

## 📱 Step 4 — Android Manifest
Add to `android/app/src/main/AndroidManifest.xml` inside `<application>`:
```xml
<meta-data
  android:name="com.google.android.gms.ads.APPLICATION_ID"
  android:value="ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX"/>
```

Add permissions above `<application>`:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
```

---

## 🎨 App Flow
```
Launch → Splash Screen (2s animated logo)
           ↓
        First time? → Onboarding (5 slides, swipeable)
           ↓
        Google Sign-In Screen
           ↓
        Home Dashboard
        ├── Home Tab    → Energy check-in + today's tasks
        ├── Plan Tab    → Weekly view
        ├── AI Tab ✦   → Chat with AURA (center CTA button)
        ├── Insights    → Energy patterns + stats
        └── Profile     → Settings + upgrade
```

---

## 📤 Step 5 — Distribute via Instagram (No Play Store)

### Host the APK (Free options):
- **Google Drive** → Upload APK → Share link (anyone with link)
- **GitHub Releases** → Create release → Attach APK
- **Mediafire.com** → Free file hosting, direct download link

### Instagram Bio Setup:
1. Create Linktree (free) or Carrd landing page
2. Add your APK download link + "How to install" guide
3. Set as your Instagram bio link

### Instagram Content (First 30 days):
- Week 1: Problem posts ("Why your to-do list isn't working")
- Week 2: Solution teaser (blurred app screenshots)
- Week 3: Demo Reels (screen recording the app)
- Week 4: User testimonials from beta testers

---

## 💰 Monetization (Future)
When ready to charge:
1. Add `purchases_flutter` package (RevenueCat — free tier)
2. Gate Pro features behind paywall
3. Or: collect leads via Instagram → sell via direct PayPal/Stripe link

---

## 🛠️ Customization Checklist
- [ ] Replace `YOUR_GEMINI_API_KEY` in ai_chat_screen.dart
- [ ] Add `google-services.json` from Firebase
- [ ] Update package name in `android/app/build.gradle`
- [ ] Add your app icon in `android/app/src/main/res/`
- [ ] Add real images to `assets/images/` (update pubspec.yaml)
- [ ] Update app name in `android/app/src/main/AndroidManifest.xml`

---

## 📞 Support
Built with Flutter + Gemini AI + Google Sign-In
All free tiers. Zero cost to launch.
